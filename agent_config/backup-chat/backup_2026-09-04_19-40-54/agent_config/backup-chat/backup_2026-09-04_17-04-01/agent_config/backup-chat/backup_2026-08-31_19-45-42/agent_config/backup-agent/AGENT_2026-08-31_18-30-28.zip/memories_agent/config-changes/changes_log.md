﻿# Міграція файлів у 2026-08-22 13:02

## Що відбулося в цьому файлі: Ціль — перенести всі AGENT/ файли під symlink'и.

### Основні зміни:
1. **Структура AGENT/** стала контейнером для symlink-ів, а не для самих файлів. Всі підкаталоги та файли тепер є symbolic link'ами на реальні каталоги в `AGENT\agents`, `AGENT\memories_agent`, `AGENT\skills`, тощо.

2. **Список symlink'ів:**
   - `agents` → AGENT\agents
   - `memories_agent` → AGENT\memories_agent
   - `skills` → AGENT\skills
   - `knowledge-base` → AGENT\knowledge-base
   - `hooks` → AGENT\hooks
   - `state` → AGENT\state
   - `scripts` → AGENT\scripts

3. **Внутрішні symlink'и:** Кожен підкаталог також містить свої symlink'и (наприклад, `AGENT/memories_agent/session/` — це symlink на `AGENT\memories_agent\session\`).

4. **Next steps заплановані в лозі:**
   - Перенести `.github\agents\Comfy-smart-lady.md` у `AGENT\agents\Comfy-smart-lady.md`
   - Перемістити session/error/action логи з `.github/memories/` на symlink'и під `AGENT/*`
   - Зафіксувати symlink'і в config-changes

Цей файл описує повну структуру міграції і plans для повного перенесення всіх файлів в AGENT/.
## 2026-08-22 22:11 — Cline (ox-alpha, онлайн)
- `scripts/sync-agent.py`: виправлено `BackupManager.create_backup` (WinError 32 при повторному запуску на існуючу ціль — абсолютний шлях замінював базу backup_dir). Додано guard від self-copy. Верифіковано повторним запуском.
## 2026-08-22 22:42 — Cline (ox-alpha, онлайн): повнота установки (v1.1.0)
- Проблема: установка в новий проект була неповною (72 файли): не копіювались кореневі файли, stub .github/agents, Loops.json у .github/hooks, agent_startup.py, більшість .continue/.
- Фікс: manifest.json 1.1.0 (+root_files 14, +2 stubs GitHub/Continue, +Loops.json→.github/hooks, +agent_startup.py); sync-agent.py — підтримка секції root_files; agent_startup.py канонізовано в AGENT/scripts/; VERSION → 1.1.0.
- Тест v3 (з робочої копії): чекліст 25/25 OK, 92 файли, py_compile = 0.
- ⚠️ install.ps1/install.sh клонують закомічений стан — повна установка запрацює тільки після commit+push цих змін.
## 2026-08-22 22:50 — Cline (ox-alpha, онлайн): end-to-end верифікація v1.1.0
- Коміт 0c70ded «Додаємо що пропустили в попередньому коміті» запушено в origin/main (6 файлів, +178/−10).
- Фінальний тест через справжній install.ps1 (клон закоміченого стану): %TEMP%\Comfy-install-final-20260822-224606 → чекліст 25/25 OK, 90 файлів.
- Раніше неповні установки: %TEMP%\Comfy-install-20260822-223033 (v1) та ...-v2-... (v2) — застарілі, можна видалити.
## 2026-08-22 22:58 — Cline (ox-alpha, онлайн): templates/ + очищення temp
- З'ясовано: кореневий templates/ = runtime-бэкапи watcher'а (як backup/) — не розповсюджується; watcher сам створює папку при першому запуску (mkdir exist_ok). AGENT/templates/stub_agents.md розповсюджується в складі ядра AGENT/.
- Баг: scripts/watch_agent_file.py мав жорсткі шляхи D:\GEN\... → виправлено на динамічний workspace (Path(__file__).parents[1]). Коміт 975cde5, запушено в main.
- Очищено всі 4 тестові папки %TEMP%\Comfy-install-* (v1, v2, v3, final).## 2026-08-26 — автоматична перегенерація manifest.json (V3 + правила)
- Створено `agent_config/scripts/delete_to_trash.py` — Корзина для видалених файлів (перенос у `agent_config/trash/` + запис у `deletion_log.md`).
- Оновлено головну інструкцію `AGENT/agents/Comfy-smart-lady.md`: правило «Видалення тільки через Корзину» та «Авто-конфігурація нових файлів».
- Переписано `agent_config/Install_Comfy-smart-lady-agent.txt` як перелік УМОВ правильної інсталяції (без жорстких команд).
- Створено `agent_config/scripts/update-manifest.py` — авто-оновлення manifest.json зі структури AGENT/ + agent_config/.
- Перегенеровано `agent_config/manifest.json` (v1.2.0, files=12, root_files=28) включає нові скрипти та інструкцію.
## 2026-08-26 15:40 - Comfy-smart-lady: perevirka skriptiv agenta
- agent_startup.py (AGENT/scripts i .github/scripts): vypr. shlyah watcher scripts/ -> AGENT/hooks/; pattern detektsii '*watch_agent_file.py*'. Skript vyhodyt 0.
- AGENT/hooks/watch_agent_file.py (kopiya .github/hooks/): vprav. 2 bagy - FileNotFoundError persh popysu logu (append) ta WORKSPACE parents[1]->parents[2].
- update-manifest.py: dodano rozpovsudzhennya hooks/watch_agent_file.py -> .github/hooks/ (files 12->13). manifest.json peregenerovano.
- Zastarilyi dublikat agent_config/scripts/watch_agent_file.py vydaleno cherez Korsynu delete_to_trash.py.

## 2026-08-26 - Comfy-smart-lady: type-fix reconfigure + trash out of manifest
- delete_to_trash.py, update-manifest.py: sys.stdout.reconfigure replaced with type-safe getattr pattern (fixes linter warning about TextIO). Runtime unchanged.
- update-manifest.py: SKIP_DIRS += trash so deleted files are not emitted into manifest root_files (29->26 after regen).

## 2026-08-26 16:15 - Comfy-smart-lady: perevirka vsih skryptiv + 3 fixy
- agent_config/scripts/migrate-to-central-agent.py: dodano import sys + type-safe stdout.reconfigure(UTF-8) — fix UnicodeEncodeError (emoji) na cp1251-konsolei. Perevirano: --collect exit 0.
- agent_config/scripts/install.ps1, test_install.ps1: perekodovano u UTF-8 z BOM — fix parsynhu PowerShell 5.1 (bez BOM korylatsia/emoji lamaly parser). Parser::ParseFile = 0 pomylOK.
- Znahodka (ne vpravleno): u git HEAD stara struktura (scripts/), nova agent_config/ untracked → install.ps1 via git clone ne znakhodyt sync-agent.py. Potriben commit novoi struktury.

## 2026-08-26 16:40 - Comfy-smart-lady: sync-agent.py type-fix reconfigure
- sync-agent.py main(): hasattr-variant -> type-safe getattr pattern dlya stdout+stderr (lynter: TextIO ne znaye reconfigure). py_compile=0, --version=1.2.0 exit 0. Prymykh vyklykiv reconfigure v repo bilshye nemae.

## 2026-08-28 13:40 - Comfy-smart-lady: consistency audit scripts + canonical-stub strategy
- update-manifest.py: DEFAULT_FILES += hooks/str.translate.py (→ .github/hooks, .clinerules/hooks, .continue/hooks, .opencode/hooks); agents/Comfy-smart-lady.md завжди action=stub (інструкції = посилання, не копія).
- sync-agent.py: self-sync guard (source==target → skip, WinError 32 fix); inline stub-шаблон використовує ${workspace} (був абсолютний шлях); git subprocess → encoding='utf-8', errors='replace' (UnicodeDecodeError на cp1251 fix); inline stub-шаблон став настійливим ("Після привітання читай та виконуй канонічний файл агента").
- .github/copilot-instructions.md: записано як настійливий stub з ${workspace} (жорсткий шлях D:\GEN прибрано). GitHub Copilot читає цей файл автозавантаженням і далі може читати канонічний AGENT/agents/Comfy-smart-lady.md — повна копія НЕ потрібна.
- AGENT/hooks/str.translate.py розповсюджено в .github/hooks, .clinerules/hooks, .continue/hooks, .opencode/hooks (self-sync --apply).
- Кореневі skills/ та knowledge-base/ (артефакти старого manifest) видалено через delete_to_trash.py (→ trash/2026-08-28_*).
- README chats/github-copilot: "порожні папки" → "stub-посилання".

## 2026-08-28 14:05 - Comfy-smart-lady: skills/knowledge-base у чатах → stub-посилання (без копій!)
- Принцип проєкту (підтверджено користувачем): канонічні інструкції (agents/, skills/, knowledge-base/) НЕ повинні мати копій у папках чатів — лише stub-посилання на AGENT/. Копіями залишається ТІЛЬКИ виконавчий код (hooks .py, .js, json, scripts) для роботи хуків.
- update-manifest.py: build_files() централізовано через STUB_KEYS = {agents/*, skills/{d}/SKILL.md, knowledge-base/README.md} → action=stub; виконавчі скрипти лишаються copy_full. Виправлено помилку попереднього commit (було skills=copy_full).
- manifest.json перегенеровано: skills/6 + knowledge-base → action=stub; перевірено action для кожного entry.
- self-sync --apply: .github/skills/*, .clinerules/skills/*, .github/knowledge-base/README.md, .clinerules/knowledge-base/README.md → перетворено на stub-посилання "${workspace}/AGENT/...". Старі повні копії автоматично збережено BackupManager у backup/.
- Верифікація: hash skills GH/CL ≠ AGENT (stub ✓); knowledge-base GH/CL ≠ AGENT (stub ✓); виконавчі копії (.github/hooks/anti_loop.py, str.translate.py, agent_startup.py, Loops.json, .opencode/plugin/anti-loop.js) = AGENT (SAME ✓).
- agent_config/README.md: структура .github/.clinerules — skills/knowledge-base описані як "stub-посилання", виконавчий код — як "копія (виконавчий код)".
- README chats/github-copilot: повернуто "stub-посилання на канонічні".

## 2026-08-28 14:25 - Comfy-smart-lady: fix sum() у anti_loop.py (змішані типи)
- AGENT/hooks/anti_loop.py: target_count = sum(...) генератор повертав суміш "" (str) при порожньому current_target і bool → помилка типізатора "No overloads for sum" + латентний TypeError на runtime.
- Фікс: target_count рахується лише коли current_target непорожній; генератор повертає суто bool.
- Верифіковано: py_compile OK; вхід із порожнім filePath → exit 0 (раніше TypeError).
- Синхронізовано в .github/hooks/anti_loop.py (self-sync), hash SAME.
- ✅ Також підтверджено: delete_to_trash.py НЕ автозавантажується на старті (це утиліта за викликом), на відміну від anti_loop/watcher/str.translate. Він розповсюджується через manifest.json (root_file).

## 2026-08-28 14:40 - Comfy-smart-lady: видалено EXECUTED+OUTDATED плани в Корзину
- За вказівкою користувача видалено 4 файли з маркером `<!-- ⏩ EXECUTED + OUTDATED ... -->` на 1-му рядку через delete_to_trash.py (спершу dry-run):
  - agent_config/DUAL_REPO_INTEGRATION_PLAN.md
  - agent_config/INTEGRATION_PLAN_V3.md
  - agent_config/docs/DEPLOY_EXISTING_PROJECT.md
  - agent_config/docs/agent-sync-plan.md
- Перенесені до agent_config/trash/2026-08-28_*.md + запис у trash/deletion_log.md (git показує як D).
- manifest.json перегенеровано (update-manifest.py --apply): root_files 34→30, видалених файлів більше не містить (щоб sync їх не відновлював).
- Примітка: FINAL_STATUS.md лише згадує маркер у таблиці — він НЕ є файлом-кандидатом, лишився.

## 2026-08-28 15:10 - Comfy-smart-lady: обмеження бекапів до 10 (backup/ та templates/)
- За вказівкою користувача обмежено кількість бекапів до 10, видаляючи найстаріший при досягненні 10.
- agent_config/scripts/sync-agent.py (BackupManager): додано MAX_BACKUPS=10 та _prune_old_backups() — видаляє найстаріші папки backup_* понад 10. Викликається після створення нової папки (у create_backup після mkdir), щоб не перевищувати 10.
- AGENT/hooks/watch_agent_file.py: додано MAX_BACKUPS=10 та prune_old_backups() — видаляє найстаріші файли Comfy-smart-lady_*.md у templates/ понад 10. Викликається після кожного create_backup. (log_message визначається пізніше в модулі — виклик у runtime безпечний.)
- Синхронізовано watch_agent_file.py у .github/hooks/ (self-sync); sync-agent.py не потребує розповсюдження в себе (self-copy guard).
- Перевірено: py_compile/ast OK; тест на 11 папках → видалено найстарішу, лишилось 10.
- ⚠️ Примітка: живий watcher-процес працює зі старою версією — нове обмеження templates підхопиться після перезапуску watcher (через agent_startup.py).



## 2026-08-28 — Додано щоденну синхронізацію в інструкцію агента
- У AGENT/agents/Comfy-smart-lady.md додано підрозділ <Щоденна синхронізація нових файлів (один раз на добу, при першому запуску)>
- Правило: при першому запуску доби запускати update-manifest.py --apply + sync-agent.py --source . --target . --apply
- Ознака, що доба вже була: існування AGENT/memories/session/session_YYYY-MM-DD.md на початку сесії
- Зміна внесена за запитом користувача 2026-08-28

## 2026-08-28 — Об'єднано блоки оновлення структури в інструкції агента
- У AGENT/agents/Comfy-smart-lady.md два підрозділи (Додавання нових функціональних файлів + Щоденна синхронізація) об'єднано в один: <Оновлення структури агента: збір нових файлів у конфігурацію (авто-конфігурація)>
- Два тригери: подія (новий файл у AGENT/ або agent_config/) та доба (перший запуск доби, ознака — файл сесії дня)
- Один ланцюжок: update-manifest.py --dry-run / --apply + sync-agent.py --source . --target . --apply
- Обмеження: щоденний тригер не частіше 1 разу на добу; подієвий — щоразу при додаванні файлу


## 2026-08-28 - Міграція агентних подій з memories/ у memories_agent/
- Події, пов'язані зі змінами Агента, перенесено з проєктних memories/ до
  внутрішньої пам'яті агента (session/, actions/) - правило з канонічної інструкції.
- Нові файли: AGENT/memories_agent/session/session_2026-08-18.md (перенесено).
- Доповнено: session_2026-08-26.md, action-log_2026-08-26.md (інтеграція V3),
  action-log_2026-08-28.md (щоденна синхронізація, видалення migrate-скрипта,
  оновлення інструкції).
- У memories/ лишились лише проєктні події + крос-референси на memories_agent/.

## 2026-08-28 - Прибрано дзеркальне копіювання .continue у agent_config/.continue
- Причина: накопичення зайвих backup-копій (sync-agent.py робив backup перед кожним
  копіюванням) та подвійні записи в root_files manifest.
- update-manifest.py: видалено блок CONTINUE_FILES (джерело: .continue/* -> agent_config/.continue/*).
- agent_config/.continue перенесено в Корзину (2026-08-28_.continue); копії файлів
  залишаються в backup/ та в кореневій .continue/ (жива конфігурація Continue).
- manifest перегенеровано: root_files 29 -> 17, записів agent_config/.continue — 0.

## 2026-08-28 - backup та templates перенесено в agent_config/
- sync-agent.py BackupManager: backup_dir = target_root/agent_config/backup/backup_<час>
  (було target_root/backup). Кореневий backup/ більше не наповнюється.
- watch_agent_file.py (канон AGENT/hooks + копія .github/hooks): BACKUP_DIR =
  agent_config/templates (було кореневий templates/).
- Наявні watcher-бекапи (6) та watcher_log перенесено з templates/ в
  agent_config/templates (8 файлів); кореневий templates/ видалено через Корзину.
- agent_config/backup не потрапляє в manifest (SKIP_DIRS), тому бекапи не
  розсилаються в цільові проєкти. Watcher на момент зміни не був запущений —
  новий шлях набуде чинності при наступному старті (agent_startup.py).

## 2026-08-28 18:38 — Git-ігнори: локальна схема
- Додано AGENT/.gitignore, .github/.gitignore, .clinerules/.gitignore, .continue/.gitignore (__pycache__/, *.pyc, state/, *.log)
- Оновлено agent_config/.gitignore (trash/* без deletion_log.md; прибрано мертві правила), .opencode/.gitignore (+Python-кеш)
- Рішення: без кореневого .gitignore-merge в хост-проєкти — безконфліктна установка через локальні ігнори в папках агента

## 2026-08-28 18:55 — v1.3.0: дві корзини + .gitignore у manifest
- delete_to_trash.py: дві корзини (AGENT/trash — файли Агента, agent_config/trash — файли проєкту)
- update-manifest.py: дистрибуція локальних .gitignore (AGENT/.gitignore у files; .github/.clinerules/.continue у root_files)
- VERSION 1.2.0 -> 1.3.0; manifest.json перегенеровано

## 2026-08-28 19:12 — Корзина проєкту -> коренева trash/
- TRASH_PROJECT_DIR перенесено з agent_config/trash у <root>/trash (delete_to_trash.py)
- trash/.gitignore створено; вміст agent_config/trash мігрував у trash/; manifest: + trash/.gitignore, trash/deletion_log.md

## 2026-08-28 19:40 — Автоперевірка оновлень (v1.3.0)
- sync-agent.py: --check-update (raw → git clone fallback для приватних репо)
- agent_startup.py: тиха check_for_updates() при старті (кеш 24год, stан в AGENT/state/ignored)
- manifest: секція update_check {repo_url, git_url, mode=notify, interval_hours, timeout_seconds}
- Install_comfy-smart-lady-agent.txt: додано Частина V пункт 4 про оновлення

## 2026-08-30 21:11 — v1.4.0: BUG-agent-lock закрито (Варіант Б)
- sync-agent.py: підкоманди status/remove/gitignore на основі agent-lock.json; remove через Корзину (delete_to_trash.py); кореневий .gitignore таргету не чіпається (ігнор через локальні .gitignore папок); дедуплікація шляхів; UTF-8 reconfigure для підкоманд; docstring+версія 1.4.0.
- delete_to_trash.py: параметр --root + _resolve_workspace для маршрутизації корзин у довільному таргеті.
- Очищено репо: прибрано закомічений agent-lock.json та __pycache__/*.pyc; додано skill-stub information-search; оновлено кореневий .gitignore.
- install.sh / install.ps1: перевірки agent-lock.json + status; відновлено test_install.ps1.
- Документація: Install_Comfy-smart-lady-agent.txt §2+ЧV, CHANGELOG v1.4.0, SCRIPTS_CATALOG, VERSION 1.3.0->1.4.0, manifest.json version.
- Валідація: py_compile 0; інтеграційний цикл у temp успішний. Коміт 3b511ea.

## 2026-08-30 21:35 — Визначення «файл Агента» для Корзини підвищено до структури Агента
- Раніше choose_trash() визначав файл Агента лише як AGENT/*, тому дистрибутивні файли (.github/, .clinerules/, .continue/, .opencode/, agent_config/) йшли в проєктну корзину trash/.
- delete_to_trash.py: додано AGENT_DIRS (папки структури Агента) + _load_agent_manifest_paths() (target_paths з agent_config/manifest.json — найточніше, оновлюється через update-manifest.py --apply). choose_trash(): manifest.json -> папки Агента -> fallback за шляхом. move_to_trash()/main() пропагують agent_manifest_paths.
- sync-agent.py cmd_remove: агентські шляхи з manifest таргета передаються в delete_to_trash.
- Інструкції: AGENT/agents/Comfy-smart-lady.md, Install_Comfy-smart-lady-agent.txt §3.
- Тест: .github/.clinerules stub, SKILL.md, anti_loop.py тепер ідуть в AGENT/trash/, проєктна trash/ порожня. py_compile = 0.

## 2026-08-30 23:06 — BUG-install-discrepancies: повна інсталяція Способом B (v1.4.0)
- sync-agent.py: --apply тепер копіює все ядро AGENT/ (copytree, без state/, session/, *.log); dry-run показує це; agent-lock.json включає файли ядра (status: 170 OK).
- manifest.json root_files: +6 записів — .github/.gitignore, .clinerules/.gitignore, .continue/.gitignore, agent_config/.gitignore, trash/.gitignore, trash/deletion_log.md.
- Репо: створено AGENT/.gitignore та локальні .gitignore (.github/, .clinerules/, .continue/, agent_config/); trash/.gitignore (ігнорує все, крім .gitignore/deletion_log.md); trash/ файли force-add.
- install.ps1/install.sh: Крок 2 (копіювання ядра) прибрано — ядро розгортає тільки sync-agent.py --apply (один авторитет).
- Валідація: manifest JSON OK; py_compile = 0; dry-run + --apply у temp — ядро, всі .gitignore, обидві корзини, lock — все на місці.
- Архівація: BUG-install-discrepancies.md перенесено в AGENT/knowledge-base/history-check/ із заголовком застанови (закрито).

## 2026-08-30 23:19 — Архівація symlink-migration-plan.md (не реалізований проєкт)
- symlink-migration-plan.md перенесено в AGENT/knowledge-base/history-check/ із заголовком «❌ НЕ РЕАЛІЗОВАНИЙ ПРОЄКТ»: symlink-міграцію (план 2026-08-22) виконано на 0% і відхилено — обрано фізичну дистрибуцію ядра AGENT/ через manifest.json.
- migration-note.md (2026-08-20, міграція memories → memories_agent) залишено на місці: міграцію виконано, структура memories_agent/ діє донині.

## 2026-08-30 23:30 — Оновлено README knowledge-base/ та memories_agent/
- knowledge-base/README.md: структура приведена до факту — solutions/, api-connect/, history-check/ (правило архівації BUG-файлів), plans-for-future/, code-patterns/ (за потреби); прибрано неіснуючий external-resources.
- memories_agent/README.md: action-log/ -> actions/ (6 згадок), у структуру додано config-changes/ та cross-reference/ і migration-note.md; прибрано артефакти генератора (</content>, <parameter=filePath>).

## 2026-08-30 23:45 — Чистка memories_agent/README.md від надлишків
- Прибрано: розділ «Посилання в інструкціях» (виконана TODO 2026-08-20), «Приклад повного циклу ведення» (історичний знімок сесії 2026-08-21, дублює реальний session-файл), довгі вигадані приклади у §1-§3 (замінені короткими шаблонами), дублікат базового шаблону у «Формат записів».
- Таблицю «Розділення логів» скорочено з 6 до 3 рядків (тільки порівняння внутрішній/зовнішній).
- Файл скорочено з 234 до 106 рядків без втрати інструктивного змісту.

## 2026-08-30 23:53 — Фікс ротації бекапів + формат імен + автозапуск watcherа
- sync-agent.py BackupManager: формат імен папок backup_YYYY-MM-DD_HH-MM-SS (як у templates); prune шлях виправлено target_root/agent_config/backup (було target_root/backup — ніколи не чистив); сортування за mtime. Тест: 14 папок -> prune -> рівно 10.
14 наявних папок перейменовано у новий формат.
watch_agent_file.py: watcher_is_running() — stdout-перевірка PID замість os.system (exit 0 навіть без процесу, watcher ніколи не стартував). Watcher перезапущено: initial backup Comfy-smart-lady_2026-08-30_23-52-43.md створено.

## 2026-08-30 23:53 — Фікс ротації бекапів + формат імен + автозапуск watcherа
- sync-agent.py BackupManager: формат імен папок backup_YYYY-MM-DD_HH-MM-SS (як у templates); prune шлях виправлено target_root/agent_config/backup (було target_root/backup — ніколи не чистив); сортування за mtime. Тест: 14 папок -> prune -> рівно 10.
14 наявних папок перейменовано у новий формат.
watch_agent_file.py: watcher_is_running() — stdout-перевірка PID замість os.system (exit 0 навіть без процесу, watcher ніколи не стартував). Watcher перезапущено: initial backup Comfy-smart-lady_2026-08-30_23-52-43.md створено.

## 2026-08-31 00:15 — Бекапи ядра AGENT/ (Варіант C: watcher-знімки + бекап перед sync)
- watch_agent_file.py: моніторинг усього AGENT/ (71 файл, без state/, trash/, memories_agent/session/, *.log/*.pyc) — при будь-якій зміні повний zip-знімок agent_config/templates/agent_backups/AGENT_YYYY-MM-DD_HH-MM-SS.zip, ротація MAX_AGENT_BACKUPS=10. Одиночний бекап інструкції залишено.
- sync-agent.py: перед copytree ядра цільовий AGENT/ хоста бека́питься в backup_YYYY-MM-DD_HH-MM-SS/AGENT/ (та сама ротація MAX_BACKUPS=10); dry-run не бека́пить.
- Тести: zip чистий (без state/session/trash, 71 файл); зміна файлу -> 2 знімки; повторний sync у temp -> backup_*/AGENT/agents/Comfy-smart-lady.md = True.

## 2026-08-31 00:26 — Прибрано одиночний бекап інструкції з watcherа
Тільки AGENT zip-знімки: видалено create_backup/prune_old_backups (Comfy-smart-lady_*.md) з watch_agent_file.py; watcher стартує без INITIAL BACKUP; main() валідує AGENT_ROOT замість SOURCE_FILE. Наявні 8 Comfy-smart-lady_*.md залишено як історію. Роль .md-бекапів тепер виконують AGENT_*.zip (інструкція всередині).

## 2026-08-31 00:32 — Видалено старі .md-бекапи інструкції; agent_backups виведено з дистрибуції
9 файлів Comfy-smart-lady_*.md видалено з agent_config/templates через Корзину (AGENT/trash) — замінені AGENT_*.zip знімками.
update-manifest.py: SKIP_DIRS += agent_backups; manifest перегенеровано (templates -> тільки watcher_log.txt, root_files 22). agent_backups/ прибрано з git-індексу та додано в .gitignore (кореневий + agent_config) — локальні бекапи не комітяться і не розсилаються.

## 2026-08-31 00:40 — Політика .gitignore уточнена (корінь хоста недоторканий)
- AGENT/.gitignore: помилкове правило AGENT/trash/* виправлено на trash/ (файл лежить всередині AGENT/). Перевірено git check-ignore: AGENT/trash/* і AGENT/state/* ігноруються.
- Кореневий .gitignore центрального репо позначено коментарем «ТІЛЬКИ для центрального репо» — не розсилається і не мержиться в хости.
- Install_Comfy-smart-lady-agent.txt §2: правила AGENT/.gitignore оновлено; додано пункти про нерозсилання кореневого .gitignore та свідомий коміт agent-lock.json у хост-проєкті.

## 2026-08-31 00:47 — Документовано: кореневий .gitignore у хост-проєкті не генерується
- Install_Comfy-smart-lady-agent.txt §2: додано пункт — кореневий .gitignore у хості НЕ генерується (всі артефакти Агента покриті локальними .gitignore папок; єдиний кореневий артефакт — agent-lock.json, який свідомо комітиться). Рішення: варіант (А), без генерації.
